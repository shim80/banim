#!/bin/sh
# Install generated first-frame logos on Knulli/Batocera or muOS.
# Usage:
#   sh install_boot_logos.sh [--knulli BMP] [--muos ICO] [--muos-bmp BMP]

KNULLI_BMP=""
MUOS_ICO=""
MUOS_BMP=""

while [ "$#" -gt 0 ]; do
    case "$1" in
        --knulli)
            KNULLI_BMP="$2"
            shift 2
            ;;
        --muos)
            MUOS_ICO="$2"
            shift 2
            ;;
        --muos-bmp)
            MUOS_BMP="$2"
            shift 2
            ;;
        *)
            echo "Unknown option: $1"
            echo "Usage: sh install_boot_logos.sh [--knulli bootlogo.bmp] [--muos muoslogo.ico] [--muos-bmp bootlogo.bmp]"
            exit 1
            ;;
    esac
done

backup_once() {
    src="$1"
    [ -e "$src" ] || return 0
    [ -e "$src.bak" ] || cp "$src" "$src.bak"
}

if [ -n "$KNULLI_BMP" ]; then
    [ -f "$KNULLI_BMP" ] || { echo "Missing BMP: $KNULLI_BMP"; exit 1; }
    if [ -d /boot ]; then
        mount -o remount,rw /boot 2>/dev/null
        backup_once /boot/bootlogo.bmp
        cp "$KNULLI_BMP" /boot/bootlogo.bmp
        sync
        mount -o remount,ro /boot 2>/dev/null
        echo "Installed Knulli/Batocera bootlogo.bmp"
    else
        echo "No /boot directory found"
    fi
fi

if [ -n "$MUOS_ICO" ]; then
    [ -f "$MUOS_ICO" ] || { echo "Missing ICO: $MUOS_ICO"; exit 1; }
    if [ -d /mnt/mmc ]; then
        backup_once /mnt/mmc/muoslogo.ico
        cp "$MUOS_ICO" /mnt/mmc/muoslogo.ico
        sync
        echo "Installed muOS muoslogo.ico"
    else
        echo "No /mnt/mmc directory found"
    fi
fi

if [ -n "$MUOS_BMP" ]; then
    [ -f "$MUOS_BMP" ] || { echo "Missing BMP: $MUOS_BMP"; exit 1; }
    if [ -d /mnt/boot ]; then
        backup_once /mnt/boot/bootlogo.bmp
        cp "$MUOS_BMP" /mnt/boot/bootlogo.bmp
        sync
        echo "Installed muOS /mnt/boot/bootlogo.bmp"
    else
        echo "No /mnt/boot directory found"
    fi
fi

exit 0
